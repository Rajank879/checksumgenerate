## Contribuiton Guidelines
- Fork the repo to your account and then clone it on your machine
- Make a separate branch for the changes you make with a meaningful name
- Commit your changes to the branch
- Make a Pull Request to [master](../../tree/master) with PR body containing description of changes you made and link to its issue.
